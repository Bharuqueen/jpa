package com.cg;

public class Employee1 {
	private int employeeId;
	private String employeeName;
	private double employeesalary;
	private SBU employeebusinessUnint;
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public double getEmployeesalary() {
		return employeesalary;
	}
	public void setEmployeesalary(double employeesalary) {
		this.employeesalary = employeesalary;
	}
	
	public SBU getEmployeebusinessUnint() {
		return employeebusinessUnint;
	}
	public void setEmployeebusinessUnint(SBU employeebusinessUnint) {
		this.employeebusinessUnint = employeebusinessUnint;
	}
	@Override
	public String toString() {
		return "Employee1 Details \n----------- \n[employeeId=" + employeeId + ", employeeName=" + employeeName + ", employeesalary="
				+ employeesalary + " \n sbudetails=" + employeebusinessUnint + "]";
	}


}
