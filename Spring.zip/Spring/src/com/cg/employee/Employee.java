package com.cg.employee;

public class Employee {
	private int employeeId;
	private String employeeName;
	private double employeesalary;
	private String employeebusinessUnint;
	private int employeeage;
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public double getEmployeesalary() {
		return employeesalary;
	}
	public void setEmployeesalary(double employeesalary) {
		this.employeesalary = employeesalary;
	}
	public String getEmployeebusinessUnint() {
		return employeebusinessUnint;
	}
	public void setEmployeebusinessUnint(String employeebusinessUnint) {
		this.employeebusinessUnint = employeebusinessUnint;
	}
	
	
	public int getEmployeeage() {
		return employeeage;
	}
	public void setEmployeeage(int employeeage) {
		this.employeeage = employeeage;
	}
	
	@Override
	public String toString() {
		return "EmployeeDetails\n --------\n Employee ID:=" + employeeId  + "\n Employee Name:=" + employeeName + "\n Employee Salary:="
				+ employeesalary + " \n Employee BU:=" + employeebusinessUnint + " \n Employee Age:=" + employeeage
				+ "";
	}
	
	
}
