package com.cg;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;



public class Main {
	public static void main(String[] args){
		
		ApplicationContext context=new ClassPathXmlApplicationContext("spring1.xml");
		Employee1 employee=(Employee1) context.getBean("employee1");
		System.out.println(employee);
	}

}
