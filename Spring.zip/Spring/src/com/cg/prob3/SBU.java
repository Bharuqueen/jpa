package com.cg.prob3;

import java.util.ArrayList;
import java.util.List;

public class SBU {
	private String sbucode;
	private String sbuName;
	private String sbuHead;
	List <Employee> emplist=new ArrayList<>();
	public String getSbucode() {
		return sbucode;
	}
	public void setSbucode(String sbucode) {
		this.sbucode = sbucode;
	}
	public String getSbuName() {
		return sbuName;
	}
	public void setSbuName(String sbuName) {
		this.sbuName = sbuName;
	}
	public String getSbuHead() {
		return sbuHead;
	}
	public void setSbuHead(String sbuHead) {
		this.sbuHead = sbuHead;
	}
	public List<Employee> getEmplist() {
		return emplist;
	}
	public void setEmplist(List<Employee> emplist) {
		this.emplist = emplist;
	}
	@Override
	public String toString() {
		return "SBUDetails\n ----------\n [sbucode=" + sbucode + ", sbuName=" + sbuName + ", sbuHead=" + sbuHead +  "\n EmployeeDetails:---------\n" + emplist
				+ "]";
	}
	

}
