package com.cg;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Main {
	public static void main(String[] arg)
	{
		
			EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
			EntityManager em = factory.createEntityManager();
			AuthorDetails author= new AuthorDetails();
			author.setAuthorId(5);
			author.setFirstName("sri");
			author.setMiddleName("akki");
			author.setLastName("nikki");
			author.setPhoneno("939267854");
			em.getTransaction().begin();
			  em.persist(author);
			  AuthorDetails obj=em.find(AuthorDetails.class,4);
			  AuthorDetails obj1=em.find(AuthorDetails.class,2);
			  
			  obj.setFirstName("robin");
			  em.remove(obj1);
			

		em.getTransaction().commit();
		  System.out.println("Added to database");
	
		
	
	}
}
