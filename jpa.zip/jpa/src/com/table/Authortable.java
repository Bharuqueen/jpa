package com.table;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;



@Entity
public class Authortable {
	@Id
	private int ID;
	
	private String name;
@OneToMany

private List<booktable> book= new ArrayList<booktable>();



	public List getBook() {
	return book;
}
public void setBook(List book) {
	this.book = book;
}
	public int getID() {
		return ID;
	}
	public void setID(int iD) {
		ID = iD;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Override
	public String toString() {
		return "Authortable [ID=" + ID + ", name=" + name + ", book=" + book + "]";
	}
	

}
