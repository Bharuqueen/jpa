package com.table;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class AuthorMain {
	
	public static void main(String[] arg)
	{
		


	EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
	EntityManager em = factory.createEntityManager();
	Authortable author =new Authortable();
	booktable book=new booktable();

	author.setID(12);
	author.setName("bharu");

	book.setISBN(19);
	book.setTitle("novels");
	book.setPrice(450); 
	  author.getBook().add(book);
	em.getTransaction().begin();
  
	em.persist(author);
	
	em.persist(book);
	em.merge(author);

	em.getTransaction().commit();
	System.out.println("Saved");
	
	}

}
